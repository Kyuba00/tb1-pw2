<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $judul?></title>
</head>
<body>

<h1><?php echo $judul?></h1>


<form method="post" action="<?php echo site_url('buku/insert_submit/');?>">
	<table>
		<tr>
			<td>ID</td>
			<td><input type="text" name="id" value="" required=""></td>
		</tr>
		<tr>
			<td>Kategori Buku</td>
			<td>
				<select name="kategori_buku_id">
				<?php foreach($data_kategori_buku as $kategori_buku):?>
				<option value="<?php echo $kategori_buku['id'];?>">
					<?php echo $kategori_buku['nama'];?>
				</option>
				<?php endforeach;?>
				</select>
			</td>
		</tr>
		<tr>
			<td>Judul</td>
			<td><input type="text" name="judul" value="" required=""></td>
		</tr>
		<tr>
			<td>Stok Tersedia</td>
			<td><input type="radio" name="stok_tersedia" value="1">Tersedia</td>
			<td><input type="radio" name="stok_tersedia" value="0">Tidak</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type="submit" name="submit" value="Simpan"></td>
		</tr>
	</table>
</form>

</body>
</html>