<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title><?php echo $judul; ?></title>
</head>

<body>

	<!--link tambah data-->
	<a href="<?php echo site_url('buku/insert'); ?>">Tambah</a>
	<br /><br />

	<table border="1">
		<thead class="thead-dark">
			<tr>
				<th>ID</th>
				<th>Kategori Buku</th>
				<th>Judul</th>
				<th>Stok Tersedia</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($data_buku as $buku) : ?>
				<tr>
					<td><?php echo $buku['id']; ?></td>
					<td><?php echo $buku['nama_kategori_buku']; ?></td>
					<td><?php echo $buku['judul']; ?></td>
					<td><?php echo number_format($buku['stok_tersedia']); ?></td>
					<td>
						<a href="<?php echo site_url('buku/update/' . $buku['id']); ?>">
							Ubah
						</a>

						<a href="<?php echo site_url('buku/delete/' . $buku['id']); ?>">
							Hapus
						</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>

	<br /><br />
	<a href="<?php echo site_url('fakultas/data_export'); ?>">Export Excel</a>

</body>

</html>