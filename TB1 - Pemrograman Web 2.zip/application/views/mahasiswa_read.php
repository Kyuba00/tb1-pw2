<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title><?php echo $judul; ?></title>
</head>

<body>
	<a href="<?php echo site_url('mahasiswa/insert'); ?>">Tambah</a>
	<br /><br />

	<table border="1">
		<thead class="thead-dark">
			<tr>
				<th>NIM</th>
				<th>Fakultas</th>
				<th>Nama</th>
				<th>Gender</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($data_mahasiswa as $mahasiswa) : ?>
				<tr>
					<td><?php echo $mahasiswa['nim']; ?></td>
					<td><?php echo $mahasiswa['nama_fakultas']; ?></td>
					<td><?php echo $mahasiswa['nama']; ?></td>
					<td><?php echo $mahasiswa['gender']; ?></td>
					<td>
						<a href="<?php echo site_url('mahasiswa/update/' . $mahasiswa['nim']); ?>">
							Ubah
						</a>

						<a href="<?php echo site_url('mahasiswa/delete/' . $mahasiswa['nim']); ?>">
							Hapus
						</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>

	<br /><br />
	<a href="<?php echo site_url('fakultas/data_export'); ?>">Export Excel</a>

</body>

</html>