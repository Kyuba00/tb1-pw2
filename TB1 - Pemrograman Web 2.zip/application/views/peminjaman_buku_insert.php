<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
</head>

<body>

    <h1><?php echo $judul ?></h1>


    <form method="post" action="<?php echo site_url('peminjaman_buku/insert_submit/'); ?>">
        <table>
            <tr>
                <td>Peminjaman</td>
                <!--$data_peminjaman_buku_single['tanggal_pinjam'] : menampilkan data peminjaman_buku yang dipilih dari database -->
                <td>
                    <select name="peminjaman_id">
                        <?php foreach ($data_peminjaman as $peminjaman) : ?>
                            <option value="<?php echo $peminjaman['id']; ?>">
                                <?php echo $peminjaman['tanggal_pinjam']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Judul</td>
                <!--$data_peminjaman_buku_single['judul'] : menampilkan data peminjaman_buku yang dipilih dari database -->
                <td>
                    <select name="buku_id">
                        <?php foreach ($data_buku as $buku) : ?>
                            <option value="<?php echo $buku['id']; ?>">
                                <?php echo $buku['judul']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td><input type="submit" name="submit" value="Simpan"></td>
            </tr>
        </table>
    </form>

</body>

</html>