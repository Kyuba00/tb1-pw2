<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul ?></title>
</head>

<body>

    <h1><?php echo $judul ?></h1>


    <form method="post" action="<?php echo site_url('peminjaman/insert_submit/'); ?>">
        <table>
            <tr>
                <td>NIM</td>
                <td><input type="text" name="nim" value="" required=""></td>
            </tr>
            <tr>
                <td>Tanggal Pinjam</td>
                <td><input type="date" name="tanggal_pinjam" id=""></td>
            </tr>
            <tr>
                <td>Status Pengembalian</td>
                <td><input type="checkbox" name="status_pengembalian" id=""></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td><input type="submit" name="submit" value="Simpan"></td>
            </tr>
        </table>
    </form>

</body>

</html>