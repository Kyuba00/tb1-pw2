<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title><?php echo $judul; ?></title>
</head>

<body>

	<!--link tambah data-->
	<a href="<?php echo site_url('fakultas/insert'); ?>">Tambah</a>
	<br /><br />

	<table border="1">
		<thead>
			<tr>
				<th>ID</th>
				<th>Nama</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<!--looping data fakultas-->
			<?php foreach ($data_fakultas as $fakultas) : ?>

				<!--cetak data per baris-->
				<tr>
					<td><?php echo $fakultas['id']; ?></td>
					<td><?php echo $fakultas['nama']; ?></td>
					<td>
						<!--link ubah data (menyertakan id per baris untuk dikirim ke controller)-->
						<a href="<?php echo site_url('fakultas/update/' . $fakultas['id']); ?>">
							Ubah
						</a>

						<!--link hapus data (menyertakan id per baris untuk dikirim ke controller)-->
						<a href="<?php echo site_url('fakultas/delete/' . $fakultas['id']); ?>" onClick="return confirm('Apakah anda yakin?')">
							Hapus
						</a>

					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>

	<br /><br />
	<a href="<?php echo site_url('fakultas/data_export'); ?>">Export Excel</a>

</body>

</html>