<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul; ?></title>
</head>

<body>
    <a href="<?php echo site_url('peminjaman/insert'); ?>">Tambah</a>
    <br /><br />

    <table border="1">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th>NIM</th>
                <th>Tanggal Pinjam</th>
                <th>Status Pengembalian</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data_peminjaman as $peminjaman) : ?>
                <tr>
                    <td><?php echo $peminjaman['id']; ?></td>
                    <td><?php echo $peminjaman['nim']; ?></td>
                    <td><?php echo $peminjaman['tanggal_pinjam']; ?></td>
                    <td><?php echo $peminjaman['status_pengembalian']; ?></td>
                    <td>
                        <a href="<?php echo site_url('peminjaman/update/' . $peminjaman['id']); ?>">
                            Ubah
                        </a>

                        <a href="<?php echo site_url('peminjaman/delete/' . $peminjaman['id']); ?>">
                            Hapus
                        </a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>

    <br /><br />
    <a href="<?php echo site_url('fakultas/data_export'); ?>">Export Excel</a>
</body>

</html>