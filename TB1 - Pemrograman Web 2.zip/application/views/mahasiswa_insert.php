<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title><?php echo $judul ?></title>
</head>

<body>

	<h1><?php echo $judul ?></h1>


	<form method="post" action="<?php echo site_url('mahasiswa/insert_submit/'); ?>">
		<table>
			<tr>
				<td>NIM</td>
				<td><input type="text" name="nim" value="" required=""></td>
			</tr>
			<tr>
				<td>Fakultas</td>
				<!--$data_mahasiswa_single['nama'] : menampilkan data mahasiswa yang dipilih dari database -->
				<td>
					<select name="fakultas_id">
						<?php foreach ($data_fakultas as $fakultas) : ?>
							<option value="<?php echo $fakultas['id']; ?>">
								<?php echo $fakultas['nama']; ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="nama" value="" required=""></td>
			</tr>
			<tr>
				<td>Gender</td>
				<td>
					<input type="radio" name="gender" value="Pria">Pria
					<input type="radio" name="gender" value="Wanita">Wanita
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="Simpan"></td>
			</tr>
		</table>
	</form>

</body>

</html>