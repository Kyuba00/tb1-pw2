<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $judul; ?></title>
</head>

<body>
    <a href="<?php echo site_url('peminjaman_buku/insert'); ?>">Tambah</a>
    <br /><br />

    <table border="1">
        <thead class="thead-dark">
            <tr>
                <th>Tanggal Pinjam</th>
                <th>Judul</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data_peminjaman_buku as $peminjaman_buku) : ?>
                <tr>
                    <td><?php echo $peminjaman_buku['tanggal_pinjam']; ?></td>
                    <td><?php echo $peminjaman_buku['judul']; ?></td>
                    <td>
                        <a href="<?php echo site_url('peminjaman_buku/update/' . $peminjaman_buku['peminjaman_id']); ?>">
                            Ubah
                        </a>

                        <a href="<?php echo site_url('peminjaman_buku/delete/' . $peminjaman_buku['peminjaman_id']); ?>">
                            Hapus
                        </a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>

    <br /><br />
    <a href="<?php echo site_url('fakultas/data_export'); ?>">Export Excel</a>

</body>

</html>